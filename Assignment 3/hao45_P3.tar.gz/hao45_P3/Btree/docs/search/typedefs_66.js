var searchData=
[
  ['frameid',['FrameId',['../namespacebadgerdb.html#a1e7378fbefaea050a47e6cde929e9c01',1,'badgerdb']]]
];
